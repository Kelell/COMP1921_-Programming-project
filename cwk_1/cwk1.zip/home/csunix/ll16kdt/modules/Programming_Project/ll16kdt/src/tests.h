#ifdef TEST_H
#define TEST_H
// write out the tree to file 'quad.out'
void task1();

void task2();

void task3();

void task4();

#endif
