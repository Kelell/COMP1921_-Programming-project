
double dataFunction( double x, double y, int choice );

bool indicator( Node *node, double tolerance, int choice );
