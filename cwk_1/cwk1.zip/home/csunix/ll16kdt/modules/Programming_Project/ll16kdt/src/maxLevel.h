#ifdef MAXLEVEL_H
#define MAXLEVEL_H

int maxLevel();

#endif
