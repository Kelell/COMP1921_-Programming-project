#ifdef DESTROYTREE_H
#define DESTROYTREE_H


void destroyTree( Node *head );

#endif
