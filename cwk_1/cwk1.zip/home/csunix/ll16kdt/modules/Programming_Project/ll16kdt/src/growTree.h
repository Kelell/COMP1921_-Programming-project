#ifdef GROWTREE_H
#define GROWTREE_H

void growTree( Node *head );

#endif
