#include "stdio.h"

int maxLevel(){
  int maxLevel;
  printf("Please enter the maximum level:\n");
  scanf("%i", &maxLevel);
  return maxLevel;
}
