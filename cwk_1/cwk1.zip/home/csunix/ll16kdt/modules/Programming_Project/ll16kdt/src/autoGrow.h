#ifdef AUTOGROW_H
#define AUTOGROW_H

void autoGrow( Node *head, choice );

void autoLoop(Node *node, int tolerance, int choice);

#endif
